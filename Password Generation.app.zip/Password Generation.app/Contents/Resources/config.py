letters = 'qwertyuiopasdfghjklzxcvbnm'
numbers = '1234567890'
symbols = letters + numbers